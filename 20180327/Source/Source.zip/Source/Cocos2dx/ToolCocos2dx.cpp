#include "ToolCocos2dx.h"

#ifdef MACRO_LIB_COCOS2D

#endif //MACRO_LIB_COCOS2D
