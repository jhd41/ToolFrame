#include "HTimeOut.h"

NS_TOOL_FRAME_BEGIN

HTimeOut::HTimeOut()
{
}

HTimeOut::~HTimeOut()
{
}

NS_TOOL_FRAME_END
